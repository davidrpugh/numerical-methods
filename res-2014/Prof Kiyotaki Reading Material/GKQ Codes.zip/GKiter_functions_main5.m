clc;clear all;

GKiter_functions_params %parameters

global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar
clc;




%%Algorithm 1: iterate on all moments except Cov(Lambda,Re)

Mdet = [-0.000000001;-0.000000001;0.000000001;0.000000001;-0.000000001;0.000000001]; 
Xdet = f_steady_full2(Mdet);
M(:,1) = .5 * f_moments_full2(Xdet); %do .5 if risk really high


%%%------------------------------

M6 = 0;
x_diff3 = 1;
jj = 1;
while x_diff3 > .001;

M6save(jj) = M6;

GKiter_innerloop;

X0 = X(:,end);
M0 = M(:,end);
Mfull = f_moments_full2(X0);
M6 = Mfull(6);

x_0 = X0(1);
X_1_all = f_steady_full2(Mfull);
x_1 = X_1_all(1);

x_diff3 = abs(x_1-x_0);
x_diff3
jj = jj + 1;
end %this seems to work reasonably well. Need to figure out EQ. FOR DISCOUNT FACTOR
%%%------------------------------



X = X_1_all;





