%%%FUNCTION to find the RISK-ADJUSTED STEADY STATE as a function of:
%%%exogenous risk, credit policy, macroprudential policy

%%%May 2011
%%%Made up using solve_M.m, solve_M_newmoments.m

function Xstar_new = f_risk_adj(risk,credit,macroprud);

clc;
%%%%parameters
[beta,alpha,rho,delta,chi,varphi,psiparam,gamma,psigbar,eta,sig,epsilon,kappa,tau_s,sigma,xi,thetaparam,...
betawelf,rhopsi,rhopsi_d,D,sigma_psid,tau_cost,...
tau_cost2,nug,tau,sigma_psi,p] = parameters_function(risk,credit,macroprud);

global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d D sigma_psid tau_cost tau_cost2 psigbar nug tau sigma_psi p

  
dist = 1;
Madd = [0;0;0]; %initial value for the "additional" moments on which we iterate

%%%---------------------------------------------
while dist > .000000001
global Madd;

if tau==0
    Mbig = fmom2(fsteady_det_notau);
else
    Mbig = fmom2(fsteady2_det);
end

    
Msmall = fmom2(fsteady2(Mbig));
Minit = .5 * Mbig + .5 * Msmall; %%use this as initial value for the solver
 

[Mstar,rc]=csolve(@g,Minit,[],1e-11,300);rc 
Madd1 = fmomadd( fsteady2(Mstar) );
dist = abs( sum(Madd1-Madd) );
Madd
dist
Madd = Madd1;
end
%%%---------------------------------------------


X = fsteady2(Mstar); %this is the FINAL risk-adj. steady state -- not anymore (May 2011)

%%%---------------------------------------------
Mnew0 = .25*newmoments_may(X);
Mnew1 = newmoments_may(newsteady_may(Mstar,Madd,Mnew0));
weight = .75;
Minit = weight*Mnew1 + (1-weight)*Mnew0;


%%solve for set of moments Mnew
[Mnew_star,rc]=csolve(@g_new,Minit,[],1e-11,400,Mstar,Madd);rc 

Xstar = newsteady_may(Mstar,Madd,Mnew_star);


%%%%%---------------------------------------------------------------------
%%%make sure convergence is achieved for the THREE SETS OF MOMENTS TOGETHER
M1 = fmom2(Xstar);
M2 = fmomadd(Xstar);
M3 = newmoments_may(Xstar);


Minit_all = [M1;M2;M3];

%%solve for set of moments Mnew
[Mall_star,rc]=csolve(@g_together,Minit_all,[],1e-11,400);rc 



%%%---%%%
Xstar_new = newsteady_may(Mall_star(1:4),Mall_star(5:7),Mall_star(8:end)); %THIS is the final risk-adj steady state
%%----%%%









