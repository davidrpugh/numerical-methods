
i = 1;
x_diff = 1;
while x_diff > .001;
    
    X(:,i+1) = f_steady_full2( M(:,i) );
    Mall = f_moments_full2( X(:,i+1) );
    M(:,i+1) = [Mall(1:5);M6];
    
    if i <= 2
        x_diff = 1;
    else
        x_diff = abs( X(1,i) - X(1,i-2) );
    end
    
    X
    x_diff
    i = i+1;
end



x_diff2 = 1;
while x_diff2 > .001;
    

M0 = .5 * M(:,3) + .5*M(:,2);
clear M X 

X(:,1) = f_steady_full2( M0 );
Mall = f_moments_full2( X(:,1) ); %this is the riskadj. SS out of "arbitrary" initial conditions
M(:,1) = [Mall(1:5);M6];

X(:,2) = f_steady_full2( M(:,1) );
Mall = f_moments_full2( X(:,2) ); 
M(:,2) = [Mall(1:5);M6];

X(:,3) = f_steady_full2( M(:,2) );
Mall = f_moments_full2( X(:,3) );
M(:,3) = [Mall(1:5);M6];

x_diff2 = abs( X(1,3) - X(1,2) )

end