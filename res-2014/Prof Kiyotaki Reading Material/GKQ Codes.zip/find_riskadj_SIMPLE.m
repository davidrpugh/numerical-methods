function f=find_riskadj_capreq(xx);

global LAMBDA Re thetaparam epsilon kappa sigma R xi tau tau_s Mrk Mre

[rows,cols]=size(xx);

for i=1:cols
    

xeq = exp( xx(1,i) ) ;
Rk = exp( xx(2,i) );
Omega = exp( xx(3,i) );

Mu = Omega*(LAMBDA*(1+tau_s)*Rk - 1) + Mrk + xeq * (Omega*(1-LAMBDA*Re)- Mre);
Theta = thetaparam*(1+epsilon*xeq+.5*kappa*xeq^2);
ratio = (Omega*(LAMBDA*(1+tau_s)*Rk-1)+Mrk)/(Omega*(1-LAMBDA*Re) + tau - Mre);
Phi = Omega/(Theta-Mu);



f(1,i) = -xeq + (-1)*ratio + sqrt( ratio^2 + (2/kappa)*( 1 - epsilon*ratio) );

f(2,i) = -Omega + (1-sigma) + sigma*LAMBDA*Omega*( R + Phi*(Rk-R+xeq*(R-Re)) ) + sigma*Phi*(Mrk - xeq*Mre); 

f(3,i) = -(1-sigma*R) + (Omega/(Theta-Mu) ) * ( sigma *( ((1+tau_s)*Rk-R) - (Re-R)*xeq ) + (1-sigma)*xi);


end
