function X_Steady = fsteady2(M);
global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar Madd tau_cost2
%find steady state as function of moments



%moments
    
Mrk = M(1);
Mre = M(2); 
Momega = M(3);
Mlambdare = M(4);


Mz = Madd(1);
Mz2 = Madd(2); 
Mq = Madd(3);

%%steady state
%LAMBDA = beta;

LAMBDA = beta * (1-beta*gamma + .5*rho*(rho+1)*(Mz-beta*gamma*Mz2) )/(1-beta*gamma*(1+.5*rho*(rho+1)*Mz));
R = 1/LAMBDA;
Re = (1-Mlambdare)/LAMBDA;



%set up system of 3 eqs in x,rk,omega
xdet = 0.07437500419982;
rkdet = 0.01189041248037;
omegadet =  0.46268303712573;

xx0(1,1) = log(3*xdet); %starting value
xx0(2,1) = rkdet;
xx0(3,1) = omegadet;
         

[xxsol,rc]=csolve(@find_riskadj_SIMPLE,xx0,[],1e-09,800);rc
    function f=find_riskadj_SIMPLE(xx);
        [rows,cols]=size(xx);
        for i=1:cols

        xeq = exp( xx(1,i) ) ;
        Rk = exp( xx(2,i) );
        Omega = exp( xx(3,i) );
        
        Mus = ( (1+tau_s)*Rk - R)*Omega*LAMBDA + Mrk + (Rk-R)* Momega;
        Mue = -Mre;
        Nu = Omega+R*Momega;
        Mu = Mus + xeq*Mue;
        Theta = thetaparam*(1+epsilon*xeq+.5*kappa*xeq^2);
        ratio = Mus/(Mue+tau);
        Phi = Nu/(Theta-Mu);


        f(1,i) = -xeq + (-1)*ratio + sqrt( ratio^2 + (2/kappa)*( 1 - epsilon*ratio) );
        f(2,i) = -Omega + (1-sigma) + sigma*(Nu + Phi*(Mus + xeq*Mue));
        f(3,i) = -(1-sigma*R) + Phi * ( sigma *( ((1+tau_s)*Rk-R) - (Re-R)*xeq ) + (1-sigma)*xi);
        end
    end


   
   
xeq = exp(xxsol(1));
Rk = exp(xxsol(2));
Omega = exp(xxsol(3));
Theta = thetaparam*(1+epsilon*xeq+.5*kappa*xeq^2);
Mus = ( (1+tau_s)*Rk - R)*Omega*LAMBDA + Mrk + (Rk-R)* Momega;
Mue = -Mre;
Mu = Mus + xeq*Mue;
Nu = Omega + R*Momega;
Phi = Nu/(Theta-Mu);

%Qexp = 1;
Qexp = 1 - psiparam*Mq;

MPK = Qexp*( Rk - (1-delta) );
qexp = MPK / (Re - (1-delta) );
KL = ( MPK/alpha )^(1/(alpha-1));
YL = KL^alpha;


L = ( (1-alpha)*YL*( 1 - beta*gamma*(1+.5*rho*(rho+1)*Mz) )/chi )^(1/varphi);

K = KL*L;
Output = YL*L;
CL = YL - delta*KL;
C = CL*L;
I = delta*K;
Zexp = C - gamma*C - chi*L^(1+varphi)/(1+varphi);
Uc = (1-beta*gamma)*Zexp^(-rho);
zexp = 1;



rkbar = Rk;
psig = psigbar;
N = Qexp*K*(1-psig)/Phi;
Spread = Rk - R;
Phic = Phi/(1-psig);
%%------------------------------
K_totaleq = K/(N+xeq*K);
outeq_totaleq = xeq*K/(N+xeq*K);
annual_spread = ( beta*(Rk-R)+1 )^4 - 1;
%%------------------------------

X_Steady( 1,1) = xeq;
X_Steady( 2,1) = K;
X_Steady( 3,1) = C;
X_Steady( 4,1) = I;
X_Steady( 5,1) = N;
X_Steady( 6,1) = Qexp;
X_Steady( 7,1) = qexp;
X_Steady( 8,1) = R;
X_Steady( 9,1) = Rk;
X_Steady(10,1) = Re;
X_Steady(11,1) = Uc;
X_Steady(12,1) = Output;
X_Steady(13,1) = psig;
X_Steady(14,1) = LAMBDA;
X_Steady(15,1) = Phi;
X_Steady(16,1) = Phic;
X_Steady(17,1) = Theta;
X_Steady(18,1) = Nu;
X_Steady(19,1) = Omega;
X_Steady(20,1) = Mu;
X_Steady(21,1) = Mus;
X_Steady(22,1) = Mue;
X_Steady(23,1) = L;


end


 
    
    
    
    
    
    
    
    
    

