anothertest.m - simulates the process, y(t) = rho*y(t-1) + alph* y(t-1)^2 + epsilon

run.m - generates lots of graphs some of which are in the handout.

second.m - computes 2nd order approximation for neoclassical model.