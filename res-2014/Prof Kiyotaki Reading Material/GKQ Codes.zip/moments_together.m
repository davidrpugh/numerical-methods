function M = moments_together(X);
%%%function giving FULL set of moments as function of steady state

M = [fmom2(X);fmomadd(X);newmoments_may(X)];