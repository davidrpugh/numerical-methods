function  g_output = g_new(Mnew,Mstar,Madd);
%%%%FUNCTION TO CONVERGE on the new set of moments, for Rk and Re
[rows,cols]=size(Mnew);
       
for i=1:cols
    
g_output(:,i) = Mnew - newmoments_may( newsteady_may(Mstar,Madd,Mnew) );

end