%%%PARAMETERS as function of risk, credit policy, macroprudential policy
function [beta,alpha,rho,delta,chi,varphi,psiparam,gamma,psigbar,eta,sig,epsilon,kappa,tau_s,sigma,xi,thetaparam,...
         betawelf,rhopsi,rhopsi_d,D,sigma_psid,tau_cost,...
         tau_cost2,nug,tau,sigma_psi,p] = parameters_function(risk,credit,macroprud);

     
if risk==1
    risk_param = 4.25; %%High risk is risk==1
else
    risk_param = .9;
end


%%%parameters

       
nx = 17; %number of state variables
ny = 34; %number of control variables
ne = 2; %number of exogenous shocks


rho = 2;
beta = 0.9900;
betawelf = 0.9900;
alpha = 0.3300;
delta = 0.0250;
chi = 0.2500;
varphi = 1/3;
psiparam = 1;
gamma = 0.75;


psigbar = 0;
nug = credit; %%policy parameters 


%%%macroprudential policy
tau = macroprud;
         
tau_s = 0;


%eff_cost_params = tau_calib(0); %the argument here is the annual efficiency cost per unit intermediated, taking the average intervention over the first 2 years, in bps (see tau_calib) 
eff_cost_params = tau_calib2(0); %same but with quadratic on the whole thing


tau_cost = eff_cost_params(1); %%%efficiency cost of intervention 
tau_cost2 = eff_cost_params(2); % quadratic part of efficiency cost


%%W NEW CALIB:
%%Rk with no macroprud. pol.: 1.01202040339323 (in det SS)
%%Rk with macroprud. pol.(tau=0.002438*1.5) :   1.01211447654210 (in det SS)
%%Rk with macroprud. pol.(tau=0.002438* 3 ) :   1.01235868296108 (in detSS)
%% then subsidy  tau_s = Rk(macroprud)/Rk(no macroprud) - 1


% % %%%%%%-----------------------
% % %%%%%%% PICK RISK HERE: old calibration - version feb 2011
sigma_psi =  0.0039 * risk_param; %low risk is times .9; high risk is times 4.25
p = 0.0156 * risk_param; 
%----------------------



D = -0.0500;
sigma_psid = sqrt( p*(1-p)*D^2 );


rhopsi = 0;
rhopsi_d = 0;


%%%----------------------------------------
%%%%%%% Old calibration - version feb 2011;also may 2011 finally
kappa = 25 * .65  * .825;
epsilon =  -1.859375 * .65;
%%%----------------------------------------


sigma = 0.9685;

thetaparam =  0.264;
xi = 0.0482 * .6;
%%%%------------------------


etatilde = [sigma_psi  0
             0  sigma_psid];
eta = [zeros(nx-ne,ne);etatilde];
sig = 1;   
%%%------------------------
SD_shock = sqrt( sigma_psi^2 + sigma_psid^2 );
