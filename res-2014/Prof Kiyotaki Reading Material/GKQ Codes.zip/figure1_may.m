%%%Build ENTIRE Figure1 (new version - may)

clc;clear all;close all;
X_low = f_risk_adj(0,0,0);
[IRF_low,Names]=ffigure1(X_low);

clear global 

X_high = f_risk_adj(1,0,0);
[IRF_high,Names]=ffigure1(X_high);
load RBC_IRFs.mat;
close all;
%%%IRF = [IRFr IRFspread IRFoutput IRFc IRFinv IRFl IRFQ IRFn IRFx];
%%%IRFrbc = [IRFrbc_r NaN(sss) IRFrbc_output IRFrbc_c IRFrbc_inv IRFrbc_l
%%%          IRFrbc_Q NaN(sss) NaN(sss)];

figure
subplot(3,3,1);plot1=plot(1:40,IRF_low(:,1),1:40,IRF_high(:,1),1:40,IRFrbc_r,'linewidth',1.5);
set(plot1(3),'linestyle',':','color',[.5 .5 .5]);
set(plot1(2),'linestyle','--');
title('R');

subplot(3,3,2);plot2=plot(1:40,IRF_low(:,2),1:40,IRF_high(:,2),'linewidth',1.5);
set(plot2(2),'linestyle','--');
title('Spread (annual)');

subplot(3,3,3);plot3=plot(1:40,IRF_low(:,3),1:40,IRF_high(:,3),1:40,IRFrbc_output,'linewidth',1.5);
set(plot3(3),'linestyle',':','color',[.5 .5 .5]);
set(plot3(2),'linestyle','--');
title('Output');

subplot(3,3,4);plot4=plot(1:40,IRF_low(:,4),1:40,IRF_high(:,4),1:40,IRFrbc_c,'linewidth',1.5);
set(plot4(3),'linestyle',':','color',[.5 .5 .5]);
set(plot4(2),'linestyle','--');
title('C');


subplot(3,3,5);plot5=plot(1:40,IRF_low(:,5),1:40,IRF_high(:,5),1:40,IRFrbc_inv,'linewidth',1.5);
set(plot5(3),'linestyle',':','color',[.5 .5 .5]);
set(plot5(2),'linestyle','--');
title('Investment');
legend('Low Risk','High Risk','RBC');

subplot(3,3,6);plot6=plot(1:40,IRF_low(:,6),1:40,IRF_high(:,6),1:40,IRFrbc_l,'linewidth',1.5);
set(plot6(3),'linestyle',':','color',[.5 .5 .5]);
set(plot6(2),'linestyle','--');
title('Labor');

subplot(3,3,7);plot7=plot(1:40,IRF_low(:,7),1:40,IRF_high(:,7),1:40,IRFrbc_Q,'linewidth',1.5);
set(plot7(3),'linestyle',':','color',[.5 .5 .5]);
set(plot7(2),'linestyle','--');
title('Q');

subplot(3,3,8);plot8=plot(1:40,IRF_low(:,8),1:40,IRF_high(:,8),'linewidth',1.5);
set(plot8(2),'linestyle','--');
title('Net Worth');

subplot(3,3,9);plot9=plot(1:40,IRF_low(:,9),1:40,IRF_high(:,9),'linewidth',1.5);
set(plot9(2),'linestyle','--');
title('x');



