%% alternative to GKiter_functions_main2.m
%% use SAME approach but with the 3 moments (Mrk,Mre,Momega)

clc;clear all;

GKiter_functions_params %parameters
global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar
clc;


%%Algorithm 2: start from det SS, stop when no progress, then switch to
%%midpoint; in this version try to converge on the 3 moments

Mdet =1.0e-005 *[ 1.0000
   -1.0000
    1.0000
    1.0000
    1.0000
    1.0000
    1.0000]; 
Xdet = fsteady1(Mdet);
M(:,1) = .5 * fmom1(Xdet); %do .5 if risk really high

i = 1;
x_diff = 1;
while x_diff > 0.08;
    
    X(:,i+1) = fsteady1( M(:,i) );
    M(:,i+1) = fmom1( X(:,i+1) );
    
    if i <= 2
        x_diff = 1;
    else
        x_diff = abs( X(1,i) - X(1,i-2) );
    end
    
    X
    x_diff
    i = i+1;
end


x_diff2 = 1;
while x_diff2 > .00001;
    

M0 = .5 * M(:,3) + .5*M(:,2);

clear M X 

X(:,1) = fsteady1( M0 );
M(:,1) = fmom1( X(:,1) ); %this is the riskadj. SS out of "arbitrary" initial conditions

X(:,2) = fsteady1( M(:,1) );
M(:,2) = fmom1( X(:,2) ); 

X(:,3) = fsteady1( M(:,2) );
M(:,3) = fmom1( X(:,3) );


x_diff2 = abs( X(1,3) - X(1,2) ); 
X

end