%%%% solve for vector of moments M using g function
%%%% THIS IS THE FINAL FILE AS OF MAY 2011
%%%% COMPUTES ITERATION BY SOLVING FOR SET OF MOMENTS BY LOOKING FOR ZERO
%%%% OF A FUNCTION (using csolve)


clc;
GKiter_functions_params %parameters
global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost tau_cost2 nug psigbar


dist = 1;
Madd = [0;0;0]; %initial value for the "additional" moments on which we iterate

%%%---------------------------------------------
while dist > .000000001

global Madd;

if tau==0
    Mbig = fmom2(fsteady_det_notau);
else
    Mbig = fmom2(fsteady2_det);
end

    
Msmall = fmom2(fsteady2(Mbig));
Minit = .5 * Mbig + .5 * Msmall; %%use this as initial value for the solver
 

[Mstar,rc]=csolve(@g,Minit,[],1e-11,300);rc 
Madd1 = fmomadd( fsteady2(Mstar) );
dist = abs( sum(Madd1-Madd) );
Madd
dist
Madd = Madd1;

end
%%%---------------------------------------------


X = fsteady2(Mstar); %this is the FINAL risk-adj. steady state

%%%get table and plot IRF
[IRF1,Names1]=ffigure1(X);






