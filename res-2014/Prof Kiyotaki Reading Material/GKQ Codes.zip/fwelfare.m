function welf_riskadj = fwelfare(X_Steady);

global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar  tau_cost2
  
L = X_Steady(23,1);
C = X_Steady(3,1);

Z = (1-gamma)*C - chi*L^(1+varphi)/(1+varphi);
varZ = fmom_Z(X_Steady);
E_U = (Z^(1-rho) )*( (1/(1-rho)) - (rho/2)*varZ);

welf_riskadj = (1/(1-beta))*E_U;