%%%BUILD FIGURE 6
%%%%Low Risk, no credit pol.. Macroprud. vs No Policy vs RBC

%%% Panels: zeta (credit pol)/x/spread // output/c/inv

clc;clear all;close all;
X_macroprud = f_risk_adj(0,0,0.006095);
[IRF_macroprud,Names]=ffigure2may(X_macroprud); 

clear global 
X_nopolicy = f_risk_adj(0,0,0);
[IRF_nopolicy,Names]=ffigure2may(X_nopolicy);


%IRF = [IRFr IRFspread IRFoutput IRFc IRFinv IRFl IRFQ IRFn IRFx IRFpsig];
%IRF = [IRFr IRFspread IRFoutput IRFc IRFinv IRFl IRFQ IRFn IRFx IRFpsig];
%%%%%%%   1     2           3      4    5      6    7   8    9      10

zetapos=10;
xpos=9;
spreadpos=2;
outputpos=3;
cpos=4;
invpos=5;
close all;
load RBC_IRFs.mat;

figure
% % % subplot(2,3,1);plot1=plot(1:40,IRF_macroprud(:,zetapos),1:40,IRF_nopolicy(:,zetapos),'linewidth',1.5);
% % % set(plot1(2),'linestyle','--');
% % % title('\zeta');

% % % subplot(2,3,1);plot1=plot(1:40,[-.05 zeros(1,39)],'linewidth',1.5);
% % % title('Shock');

subplot(2,3,1);plot2=plot(1:40,IRF_macroprud(:,xpos),1:40,IRF_nopolicy(:,xpos),'linewidth',1.5);
set(plot2(2),'linestyle','--');
title('x');

subplot(2,3,2);plot3=plot(1:40,IRF_macroprud(:,spreadpos),1:40,IRF_nopolicy(:,spreadpos),'linewidth',1.5);
set(plot3(2),'linestyle','--');
title('Spread (annual)');


subplot(2,3,3);plot4=plot(1:40,IRF_macroprud(:,outputpos),1:40,IRF_nopolicy(:,outputpos),1:40,IRFrbc_output,'linewidth',1.5);
set(plot4(3),'linestyle',':','color',[.5 .5 .5]);
set(plot4(2),'linestyle','--');
title('Output');

subplot(2,3,4);plot5=plot(1:40,IRF_macroprud(:,cpos),1:40,IRF_nopolicy(:,cpos),1:40,IRFrbc_c,'linewidth',1.5);
set(plot5(3),'linestyle',':','color',[.5 .5 .5]);
set(plot5(2),'linestyle','--');
title('C');
legend('Macroprudential Policy ','No Macroprudential Policy','RBC');

subplot(2,3,5);plot6=plot(1:40,IRF_macroprud(:,invpos),1:40,IRF_nopolicy(:,invpos),1:40,IRFrbc_inv,'linewidth',1.5);
set(plot6(3),'linestyle',':','color',[.5 .5 .5]);
set(plot6(2),'linestyle','--');
title('Investment');

