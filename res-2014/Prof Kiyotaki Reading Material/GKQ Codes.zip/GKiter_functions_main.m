%%use functions f_moments and f_steady to converge on a risk-adj. steady st
clc;clear all;


GKiter_functions_params %parameters
global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar
clc;

  
%%Algorithm 1: simply iterate starting in deterministic SS and hope to converge
Mdet = [-0.000000001;-0.000000001]; 
Xdet = f_steady(Mdet);
M(:,1) = f_moments(Xdet);

i = 1;
x_diff = 1;
while x_diff > .0005;
    
    X(:,i+1) = f_steady( M(:,i) );
    M(:,i+1) = f_moments( X(:,i+1) );
    
    if i == 1
        x_diff = 1;
    else
        x_diff = abs( X(1,i) - X(1,i-1) );
    end
    
    X
    i = i+1;
end

      
      
      
      
      
      




















% % % % % Mmin1 = [-0.00000001;-0.00000001]; 
% % % % % X0 = f_steady(Mmin1); %this is effectively the DETERMINISTIC steady state
% % % % % M0 = f_moments(X0);
% % % % % 
% % % % % X1 = f_steady(.8 * M0);
% % % % % M1 = f_moments(X1);
% % % % % 
% % % % % M(:,1) = .8 * M0;
% % % % % for i = 2:35
% % % % %     X(:,i) = f_steady( M(:,i-1) )
% % % % %     M(:,i) = f_moments( X(:,i) );
% % % % % end
% % % % % 
% % % % % 
% % % % % M0 = .5 * M(:,end) + .5*M(:,end-1);
% % % % % clear M X
% % % % % M(:,1) = M0;
% % % % % for i = 2:20
% % % % %     X(:,i) = f_steady( M(:,i-1) )
% % % % %     M(:,i) = f_moments( X(:,i) );
% % % % % end
% % % % % 
% % % % % 
% % % % % M0 = .5 * M(:,end) + .5*M(:,end-1);
% % % % % clear M X
% % % % % M(:,1) = M0;
% % % % % for i = 2:20
% % % % %     X(:,i) = f_steady( M(:,i-1) )
% % % % %     M(:,i) = f_moments( X(:,i) );
% % % % % end
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % M0 = .5 * M(:,end) + .5*M(:,end-1);
% % % % % clear M X
% % % % % M(:,1) = M0;
% % % % % for i = 2:20
% % % % %     X(:,i) = f_steady( M(:,i-1) )
% % % % %     M(:,i) = f_moments( X(:,i) );
% % % % % end
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % M0 = .5 * M(:,end) + .5*M(:,end-1);
% % % % % clear M X
% % % % % M(:,1) = M0;
% % % % % for i = 2:20
% % % % %     X(:,i) = f_steady( M(:,i-1) )
% % % % %     M(:,i) = f_moments( X(:,i) );
% % % % % end
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % M0 = .5 * M(:,end) + .5*M(:,end-1);
% % % % % clear M X
% % % % % M(:,1) = M0;
% % % % % for i = 2:20
% % % % %     X(:,i) = f_steady( M(:,i-1) )
% % % % %     M(:,i) = f_moments( X(:,i) );
% % % % % end
% % % % % 
% % % % % 
% % % % % 
% % % % % M0 = .5 * M(:,end) + .5*M(:,end-1);
% % % % % clear M X
% % % % % M(:,1) = M0;
% % % % % for i = 2:20
% % % % %     X(:,i) = f_steady( M(:,i-1) )
% % % % %     M(:,i) = f_moments( X(:,i) );
% % % % % end
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % M0 = .5 * M(:,end) + .5*M(:,end-1);
% % % % % clear M X
% % % % % M(:,1) = M0;
% % % % % for i = 2:20
% % % % %     X(:,i) = f_steady( M(:,i-1) )
% % % % %     M(:,i) = f_moments( X(:,i) );
% % % % % end
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % M0 = .5 * M(:,end) + .5*M(:,end-1);
% % % % % clear M X
% % % % % M(:,1) = M0;
% % % % % for i = 2:20
% % % % %     X(:,i) = f_steady( M(:,i-1) )
% % % % %     M(:,i) = f_moments( X(:,i) );
% % % % % end
% % % % % 
% % % % % 
% % % % % 
% % % % % 
% % % % % 





%%Vector with steady state names
Names_Steady{ 1,1} = 'xeq';
Names_Steady{ 2,1} = 'K';
Names_Steady{ 3,1} = 'C';
Names_Steady{ 4,1} = 'I';
Names_Steady{ 5,1} = 'N';
Names_Steady{ 6,1} = 'Qexp';
Names_Steady{ 7,1} = 'qexp';
Names_Steady{ 8,1} = 'R';
Names_Steady{ 9,1} = 'Rk';
Names_Steady{10,1} = 'Re';
Names_Steady{11,1} = 'Uc';
Names_Steady{12,1} = 'Output';
Names_Steady{13,1} = 'psig';
Names_Steady{14,1} = 'LAMBDA';
Names_Steady{15,1} = 'Phi';
Names_Steady{16,1} = 'Phic';
Names_Steady{17,1} = 'Theta';
Names_Steady{18,1} = 'Nu';
Names_Steady{19,1} = 'Omega';
Names_Steady{20,1} = 'Mu';
Names_Steady{21,1} = 'Mus';
Names_Steady{22,1} = 'Mue';
Names_Steady{23,1} = 'L';
