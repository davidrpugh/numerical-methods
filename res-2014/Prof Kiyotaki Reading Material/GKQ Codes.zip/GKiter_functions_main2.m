%%use functions f_moments and f_steady to converge on a risk-adj. steady st
clc;clear all;


GKiter_functions_params %parameters
global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar
clc;

  
%%Algorithm 1: start from det SS, stop when no progress, then switch to
%%midpoint
Mdet = [-0.000000001;-0.000000001]; 
Xdet = f_steady(Mdet);
M(:,1) = .5 * f_moments(Xdet); %do .5 if risk really high

i = 1;
x_diff = 1;
while x_diff > .00025;
    
    X(:,i+1) = f_steady( M(:,i) );
    M(:,i+1) = f_moments( X(:,i+1) );
    
    if i <= 2
        x_diff = 1;
    else
        x_diff = abs( X(1,i) - X(1,i-2) );
    end
    
    X
    x_diff
    i = i+1;
end



x_diff2 = 1;
while x_diff2 > .00000001;
    

M0 = .5 * M(:,3) + .5*M(:,2);
clear M X 

X(:,1) = f_steady( M0 );
M(:,1) = f_moments( X(:,1) ); %this is the riskadj. SS out of "arbitrary" initial conditions

X(:,2) = f_steady( M(:,1) );
M(:,2) = f_moments( X(:,2) ); 

X(:,3) = f_steady( M(:,2) );
M(:,3) = f_moments( X(:,3) );


x_diff2 = abs( X(1,3) - X(1,2) ); 
X

end

%next: take the value that converged. Add the rest of moments

X = X(:,3); %this is the FIXED POINT
M = f_moments_full(X);

i = 1;
k_diff = 1;
while k_diff > .000000025;
    
    X(:,i+1) = f_steady_full( M(:,i) );
    Mall(:,i+1) = f_moments_full( X(:,i+1) );
    M(:,i+1) = [M(1:2,i);Mall(3,i+1)];
    
    if i <= 2
        k_diff = 1;
    else
        k_diff = abs( X(2,i) - X(2,i-1) );
    end
    
    X
    M
    k_diff
    i = i+1;
end
      
X = X(:,end); %new fixed point
   
      
      













%%Vector with steady state names
Names_Steady{ 1,1} = 'xeq';
Names_Steady{ 2,1} = 'K';
Names_Steady{ 3,1} = 'C';
Names_Steady{ 4,1} = 'I';
Names_Steady{ 5,1} = 'N';
Names_Steady{ 6,1} = 'Qexp';
Names_Steady{ 7,1} = 'qexp';
Names_Steady{ 8,1} = 'R';
Names_Steady{ 9,1} = 'Rk';
Names_Steady{10,1} = 'Re';
Names_Steady{11,1} = 'Uc';
Names_Steady{12,1} = 'Output';
Names_Steady{13,1} = 'psig';
Names_Steady{14,1} = 'LAMBDA';
Names_Steady{15,1} = 'Phi';
Names_Steady{16,1} = 'Phic';
Names_Steady{17,1} = 'Theta';
Names_Steady{18,1} = 'Nu';
Names_Steady{19,1} = 'Omega';
Names_Steady{20,1} = 'Mu';
Names_Steady{21,1} = 'Mus';
Names_Steady{22,1} = 'Mue';
Names_Steady{23,1} = 'L';
