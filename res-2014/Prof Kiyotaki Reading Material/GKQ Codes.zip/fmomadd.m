function Mz = fmomadd(X);

M = fmom1(X);
Mz = M(5:7);