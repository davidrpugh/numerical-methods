%%%% compute welfare INCLUDING in the first order term the Z that comes out
%%%% of substracting the efficiency costs (and adj costs of capital) from
%%%% the resource constraint
function welf_riskadj = fwelfare_aug(X_Steady);


global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar Madd tau_cost2

%X_Steady_aug = fsteady_aug( fmom2(X_Steady) );  %%%This is the "augmented" steady state which includes the 2nd order terms out of the resource constraint
X_Steady_aug = fsteady_aug_newmoments( fmom2(X_Steady), fmomadd(X_Steady), newmoments_may(X_Steady) ); 

     
L = X_Steady(23,1);
C = X_Steady(3,1);

L_aug = X_Steady_aug(23,1);
C_aug = X_Steady_aug(3,1);

Z = (1-gamma)*C - chi*L^(1+varphi)/(1+varphi);
Z_aug = (1-gamma)*C_aug - chi*L_aug^(1+varphi)/(1+varphi);

varZ = fmom_Z(X_Steady);

E_U = (Z^(1-rho) )*( (1/(1-rho)) - (rho/2)*varZ) +  ( Z^(-rho) )*( Z_aug - Z);

welf_riskadj = (1/(1-beta))*E_U;