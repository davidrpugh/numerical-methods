%%%%% EXTENDS solve_M to iterate on the additional moments for Rk, Re and
%%%%% (MAINLY) for Omega: cov(theta,phi)

%%%% Maybe try iterating only on cov(theta,phi) first


clc;clear all;
solve_M; %this runs the iteration on previous moments; X is the converged steady state; 
%%Mstar is the converged first set of moments (given by fmom2); Madd is the
%%"additional" set of moments (given by fmomadd); 
%%HERE the idea is to converge on the NEW set of moments (May 2011), given
%%by newmoments_may(X); newsteady_may(Mstar,Madd,Mnew);


Mnew0 = .25*newmoments_may(X);
Mnew1 = newmoments_may(newsteady_may(Mstar,Madd,Mnew0));
weight = .75;
Minit = weight*Mnew1 + (1-weight)*Mnew0;


%%solve for set of moments Mnew
[Mnew_star,rc]=csolve(@g_new,Minit,[],1e-11,400,Mstar,Madd);rc 

Xstar = newsteady_may(Mstar,Madd,Mnew_star);


%%%%%---------------------------------------------------------------------
%%%make sure convergence is achieved for the THREE SETS OF MOMENTS TOGETHER
M1 = fmom2(Xstar);
M2 = fmomadd(Xstar);
M3 = newmoments_may(Xstar);


Minit_all = [M1;M2;M3];

%%solve for set of moments Mnew
[Mall_star,rc]=csolve(@g_together,Minit_all,[],1e-11,400);rc 

Xstar_new = newsteady_may(Mall_star(1:4),Mall_star(5:7),Mall_star(8:end));






