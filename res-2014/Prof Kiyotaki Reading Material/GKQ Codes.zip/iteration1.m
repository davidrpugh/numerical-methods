%%iterate on z-moments - MAIN ITERATION FILE

clc;clear all;

Mz0 = [0;0];
X0 = GKiter2(Mz0); %this is the SS you get assuming the z moments are 0, after you converge on the other moments

Mz1 = fmomz(X0); %these are the Z moments around X0
X1 = GKiter2(Mz1); %this is the new "converged" steady state with the Mz1 moments - COMPARE to X0

Mz2 = fmomz(X1); %compare these moments to the Mz1 moments
X2 = GKiter2(Mz2);

Mz3 = fmomz(X2);
X3 = GKiter2(Mz3);

Mz4 = fmomz(X3);
X4 = GKiter2(Mz4);


X = X4; %seems to have converged after 4 iterations - X is the FINAL steady state vector after convergence
