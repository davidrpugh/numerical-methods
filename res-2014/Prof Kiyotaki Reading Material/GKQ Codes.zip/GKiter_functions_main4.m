%% alternative to GKiter_functions_main2.m
%% use SAME approach but with all 6 moments (Mrk,Mre,Momega // Mz, Mlambdare, Mq)




clc;clear all;

GKiter_functions_params %parameters

global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar
clc;




%%Algorithm 1: iterate on all moments except Cov(Lambda,Re)

Mdet = [-0.000000001;-0.000000001;0.000000001;0.000000001;-0.000000001;0.000000001]; 
Xdet = f_steady_full2(Mdet);
M(:,1) = .5 * f_moments_full2(Xdet); %do .5 if risk really high

i = 1;
x_diff = 1;
while x_diff > .0008;
    
    X(:,i+1) = f_steady_full2( M(:,i) );
    Mall = f_moments_full2( X(:,i+1) );
    M(:,i+1) = [Mall(1:5);0];
    
    if i <= 2
        x_diff = 1;
    else
        x_diff = abs( X(1,i) - X(1,i-2) );
    end
    
    X
    x_diff
    i = i+1;
end



x_diff2 = 1;
while x_diff2 > .000000001;
    

M0 = .5 * M(:,3) + .5*M(:,2);
clear M X 

X(:,1) = f_steady_full2( M0 );
Mall = f_moments_full2( X(:,1) ); %this is the riskadj. SS out of "arbitrary" initial conditions
M(:,1) = [Mall(1:5);0];

X(:,2) = f_steady_full2( M(:,1) );
Mall = f_moments_full2( X(:,2) ); 
M(:,2) = [Mall(1:5);0];

X(:,3) = f_steady_full2( M(:,2) );
Mall = f_moments_full2( X(:,3) );
M(:,3) = [Mall(1:5);0];

x_diff2 = abs( X(1,3) - X(1,2) ); 
X

end



X = X(:,end);











