function Xss = GKiter2(M2);

%clc;clear all;
%IDEA: make the initial set of moments (Minit) an ARGUMENT, so then in the
%outer loop for the z moments, I can use the previous CONVERGED value as
%starting value for the next iteration

GKiter_functions_params %parameters
global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar
clc;

Mzz = M2(1);
Mzz2 = M2(2);

Mdet = [0.00001;-0.00001;0.00001;0.00001;0.00001;0.000001];
Xdet = fsteady2(Mdet);


Mbig = [fmom2(Xdet);Mzz;Mzz2];
Msmall = [fmom2( fsteady2(Mbig));Mzz;Mzz2];



Minit = .5*Mbig + .5*Msmall;


x_diff = 1;
while x_diff > .005;
    

Minit = .5 * Mbig + .5*Msmall;


clear M X Mbig Msmall

X(:,1) = fsteady2(Minit);
M(:,1) = fmom2( X(:,1) ); %this is the riskadj. SS out of "arbitrary" initial conditions

X(:,2) = fsteady2( [M(:,1);Mzz;Mzz2] );
M(:,2) = fmom2( X(:,2) );  %this set of moments will be large
Mbig = [M(:,2);Mzz;Mzz2];

X(:,3) = fsteady2( Mbig );
M(:,3) = fmom2( X(:,3) ); %these will be small since more hedging
Msmall = [M(:,3);Mzz;Mzz2];

X

x_diff = abs( X(2,3) - X(2,2) ); 



end

Xss = X(:,end);