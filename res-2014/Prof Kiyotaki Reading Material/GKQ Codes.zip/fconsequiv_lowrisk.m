%% welfare - consumption equivalents for the low risk case
function cons_equiv = fconsequiv(X); %input: steady state 

global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar  tau_cost2
  
      
Cnopol = 18.74177790617059;
Lnopol = 8.22446985150602;
Znopol = (1-gamma)*Cnopol - chi*Lnopol^(1+varphi)/(1+varphi);
Wnopol = -63.68814560580331; %these are the numbers for the no policy case, with high risk

Wpol = fwelfare_aug(X);

DeltaZ = (Wpol/Wnopol)^(1/(1-rho)) - 1;
DeltaC = ( 1/( (1-gamma)*Cnopol ) )*( (1+DeltaZ)*Znopol + chi*Lnopol^(1+varphi)/(1+varphi) ) - 1;

cons_equiv = 100*DeltaC; %%percent consumption equivalents
