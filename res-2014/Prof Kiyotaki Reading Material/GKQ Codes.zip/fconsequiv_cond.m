%%% CONDITIONAL welfare - consumption equivalents
%%% I DON'T KNOW IF THIS IS RIGHT

function cons_equiv = fconsequiv_cond(X); %input: steady state 

global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar  tau_cost2
  
Cnopol = 18.55730793284221;
Lnopol = 8.14836037457942;
Znopol = (1-gamma)*Cnopol - chi*Lnopol^(1+varphi)/(1+varphi);

Wnopol = -64.81657840190356 + ( -1.28376718893663 ); %these are the numbers for the no policy case, with high risk; the added term is the CONDITIONAL term

Wpol = fwelfare_aug(X) + fwelfare_cond(X);

DeltaZ = (Wpol/Wnopol)^(1/(1-rho)) - 1;
DeltaC = ( 1/( (1-gamma)*Cnopol ) )*( (1+DeltaZ)*Znopol + chi*Lnopol^(1+varphi)/(1+varphi) ) - 1;

cons_equiv = 100*DeltaC; %%percent consumption equivalents
