function  g_output = g_together(M);
%%%%FUNCTION TO CONVERGE on the FULL SET OF MOMENTS TOGETHER
[rows,cols]=size(M);
       
for i=1:cols
    
g_output(:,i) = M - moments_together( newsteady_may(M(1:4),M(5:7),M(8:end)));

end