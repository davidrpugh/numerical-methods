%%like f_moments but including full set of moments (for financial part)
function M = f_moments_full(X_Steady);
global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar
%compute moments as function of steady state

%GKcapreq_model; 
%save derivatives_firstorder.mat fx fxp fy fyp f
load derivatives_firstorder.mat;

xeq   = X_Steady( 1,1);
K     = X_Steady( 2,1);
C     = X_Steady( 3,1);
I     = X_Steady( 4,1);
N     = X_Steady( 5,1);
Qexp  = X_Steady( 6,1);
qexp  = X_Steady( 7,1);
R     = X_Steady( 8,1);
Rk    = X_Steady( 9,1);
Re    = X_Steady(10,1);
Uc    = X_Steady(11,1);
Output= X_Steady(12,1);
psig  = X_Steady(13,1);
LAMBDA= X_Steady(14,1);
Phi   = X_Steady(15,1);
Phic  = X_Steady(16,1);
Theta = X_Steady(17,1);
Nu    = X_Steady(18,1);
Omega = X_Steady(19,1);
Mu    = X_Steady(20,1);
Mus   = X_Steady(21,1);
Mue   = X_Steady(22,1);
L     = X_Steady(23,1);



%%%-------------------------------
%%%-------------------------------
%%aux stuff:
Zexp = C - gamma*C - chi*L^(1+varphi)/(1+varphi);
zexp = 1;
Spread = Rk - R;
rkbar = Rk;
%%get logs:
%%mue
mue = Mue;
mue_p = mue;
mus = log(Mus);
mus_p = mus;
% welfare - THIS IS WRONG - correct later to include 2nd moments
Welf = (1/(1-betawelf))*(1/(1-rho)) * ( C-gamma*C-chi*L^(1+varphi)/(1+varphi) )^(1-rho);
Welf_p = Welf;
Ut = (1/(1-rho)) * ( C-gamma*C-chi*L^(1+varphi)/(1+varphi) )^(1-rho);
Ut_p = Ut;


% auxiliary variables

Omegatild = LAMBDA*Omega;
Uctild = (C-gamma*C-chi*L^(1+varphi)/(1+varphi) )^(-rho);

%%logs:

omegatild = log(Omegatild);
uctild = log(Uctild);

omegatild_p = omegatild;
uctild_p = uctild;
gi = 0;
gi_p = 0;
%----------
psig_p = psig;
psigback = psig;
psigback_p = psig;
Phic = Phi/(1-psig);
%new stuff

Z = log(Zexp);
Z_p = Z;
Zback = Z;
Zback_p = Z;

z = log(zexp);
z_p = z;


%next: get logs

r = log(R);
phi = log(Phi);
phic = log(Phic);
omega = log(Omega);
nu = log(Nu);
mu = log(Mu);
theta = log(Theta);
rk = log(Rk);
re = log(Re);
l = log(L);
k = log(K);
n = log(N);
q = log(qexp);
Q = log(Qexp);
c = log(C);
uc = log(Uc);
Lambda = log(LAMBDA);
psi = 0;
psi_d = 0;
inv = log(I);
spread = log(Spread);
gy = 0;
gy_p = 0;
output = log(Output);
spread = Spread;
spread_p = spread;


xeqback = xeq;
cback = c;
Qback = Q;
invback = inv;
nback = n;
rback = r;
qback = q;
ucback = uc;
kback = k;
outputback = output;

xeqback_p = xeq;
cback_p = c;
Qback_p = Q;
invback_p = inv;
nback_p = n;
rback_p = r;
qback_p = q;
ucback_p = uc;
kback_p = k;
outputback_p = output;

xeq_p = xeq;
psi_p = psi;
psi_d_p = psi_d;
c_p = c;
Q_p = Q;
inv_p = inv;
n_p = n;
r_p = r;
q_p = q;
Lambda_p = Lambda;
r_p = r;
re_p = re;
rk_p = rk;
omega_p = omega;
phi_p = phi;
phic_p = phic;
theta_p = theta;
nu_p = nu;
mu_p = mu;
l_p = l;
uc_p = uc;
spread_p = log(Spread);
output_p = output;

nuback = nu;
nuback_p = nu;
%%new variables
phiback = phi;
phiback_p = phi;
LambdaRbar = LAMBDA * ( (Rk-R) + xeq*(R-Re) );
LambdaRbar_p = LambdaRbar;
Omega_lev = Omega;
Omega_lev_p = Omega;
%%%-------------------------------
%%%-------------------------------
%names
namesx = {'k','Z','c','inv','n','x','Q','q','r','uc','output','psig','nu','phi','psi','psi_d'};
namesy = {'Welf','Ut','Mue','Mus','z','Z','psi_g','gy','output','c','inv','r','x','Q','q','uc','Lambda',...
       'phi','phic','theta','nu','omega','mu','rk','re','l','spread','n','omegatild','uctild','gi','LambdaRbar','Omega_lev'};

omegatildpos = find(strcmp(namesy,'omegatild')==1);
repos = find(strcmp(namesy,'re')==1);
rkpos = find(strcmp(namesy,'rk')==1); 
omegapos = find(strcmp(namesy,'omega')==1);
lambdapos = find(strcmp(namesy,'Lambda')==1);
%%%%------------------------------
approx = 1;
num_eval;
[gx,hx] = gx_hx(nfy,nfx,nfyp,nfxp);
[vary,varx]=mom(gx,hx,sig^2*(eta*eta'),0);
%%%%------------------------------
cov_omegatild_Rk = vary(omegatildpos,rkpos);
cov_omegatild_Re =  vary(omegatildpos,repos);
cov_omega_lambda = vary(omegapos,lambdapos);
%%Relevant moments: (translate to levels)
Mrk = exp(Lambda) * Omega * Rk * cov_omegatild_Rk;
Mre = exp(Lambda) * Omega *exp(re) * cov_omegatild_Re;
Momega = exp(Lambda) * Omega * cov_omega_lambda;

%%function output:
M(1,1) = Mrk;
M(2,1) = Mre;
M(3,1) = Momega;
