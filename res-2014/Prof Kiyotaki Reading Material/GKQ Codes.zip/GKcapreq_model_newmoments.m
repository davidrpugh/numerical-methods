%%% GK model for computing variances and covariances, to get risk-adj ss
%%% Shifted to getting var-cov inst. of Et - use 1st order ONLY

%Define parameters

syms tau tau_s tau_cost tau_cost2 psigbar rkbar nug rho gamma beta betawelf alpha delta psiparam sigma kappa epsilon thetaparam xi chi varphi rhopsi sigmapsi rhopsi_d sigmapsi_d
 
%Define variables 

syms phiback kback Zback zback cback invback nback xeqback Qback qback rback ucback outputback psigback nuback psi psi_d;
syms phiback_p k Zback_p zback_p cback_p invback_p nback_p xeqback_p Qback_p qback_p rback_p ucback_p outputback_p psigback_p nuback_p psi_p psi_d_p;

syms Welf LambdaRbar Omega_lev Ut mue mus Z z z2 psig phic output gy gy_p c inv r n xeq Q q uc Lambda phi theta nu omega mu rk re l spread n omegatild uctild gi;
syms Welf_p Ut_p LambdaRbar_p Omega_lev_p mue_p mus_p Z_p z_p z2_p psig_p phic_p output_p c_p inv_p r_p n_p xeq_p Q_p q_p uc_p Lambda_p phi_p theta_p nu_p omega_p mu_p rk_p re_p l_p spread_p n_p omegatild_p uctild_p gi_p;

syms psi_control psi_control_p
%MODEL EQUATIONS



f1 = output - c - (1 + 0.5*psiparam*(inv/invback - 1)^2)*inv - tau_cost*psig*Q*k - tau_cost2*(psig*Q*k)^2;
%f1 = output - c - (1 + 0.5*psiparam*(inv/invback - 1)^2)*inv;


f2 = k - inv - (1 - delta)*exp(psi)*exp(psi_d)*kback;
%f2 = k - inv - (1 - delta)*exp(psi)*exp(psi_d)*kback + tau_cost*psig*Q*k;


f3 =-Q + 1 + 0.5*psiparam*(inv/invback - 1)^2  + (inv/invback)*psiparam*(inv/invback - 1)- Lambda_p*inv_p^2/inv^2*psiparam*(inv_p/inv - 1);

f4 = Q*k - phic*nback_p;

%f5 = nback_p - sigma*(( (1+tau_s) * rk-rback-(re-rback*(1 + tau/nuback ) )*xeqback)*Qback*kback*(1-psigback) +rback*nback)-(1-sigma)*xi*Qback*kback*(1-psigback);
f5 = nback_p - sigma*(( (1+tau_s) * rk-rback-(re-rback)*xeqback)*Qback*kback*(1-psigback) +rback*nback)-(1-sigma)*xi*Qback*kback*(1-psigback);

f6 = Lambda_p*r - 1;

f7 = Lambda_p*(re_p - r);

f8 = Lambda - beta*uc/ucback;

f9 = phi - nu/(theta-mu);

f10 = theta - thetaparam*(1 + epsilon*xeq + 0.5*kappa*xeq^2);

f11 = nu - Lambda_p*omega_p*r;

f12 = omega - (1-sigma) - sigma*theta*phi;

%f13 = mu - Lambda_p*omega_p*(rk_p-r-(re_p-r)*xeq);
f13 = -mu + Lambda_p*omega_p*( (1+tau_s)*rk_p-r) + mue*xeq; 

%%f14 = (epsilon + kappa*xeq)/(1 + epsilon*xeq + 0.5*kappa*xeq^2) - (1/mu)*Lambda_p*omega_p*(r-re_p); 
f14 = (epsilon + kappa*xeq)/(1 + epsilon*xeq + 0.5*kappa*xeq^2) - (1/mu)*(mue+tau);


f15 = rk - exp(psi)*exp(psi_d)*(alpha*(exp(psi)*exp(psi_d)*kback/l)^(alpha-1)+(1-delta)*Q)/Qback;

f16 = re - exp(psi)*exp(psi_d)*(alpha*(exp(psi)*exp(psi_d)*kback/l)^(alpha-1)+(1-delta)*q)/qback;

f17 = (1-alpha)*(output/l)*uc - (c-gamma*cback-chi*l^(1+varphi)/(1+varphi))^(-rho) * chi * l^varphi;

f18 = -uc + (c - gamma*cback-chi*l^(1+varphi)/(1+varphi))^(-rho) - beta*gamma*(c_p - gamma*c-chi*l_p^(1+varphi)/(1+varphi))^(-rho);

f19 = -Welf + ( 1/(1-rho) )*( c-gamma*cback-chi*l^(1+varphi)/(1+varphi) )^(1-rho) + beta*Welf_p;

f20 = -Ut + ( 1/(1-rho) )*( c-gamma*cback-chi*l^(1+varphi)/(1+varphi) )^(1-rho);

f21 = output - (exp(psi)*exp(psi_d)*kback)^alpha * l^(1-alpha);

f22 = spread - rk_p + r;

% past states

f23 = c - cback_p;

f24 = inv - invback_p; 

f25 = r - rback_p;

f26 = xeq - xeqback_p;

f27 = Q - Qback_p;

f28 = q - qback_p;

f29 = uc - ucback_p;

f30 = n - nback_p;

f31 = output - outputback_p;

f32 = psig - psigback_p;

f33 = Z - Zback_p;

f34 = nu - nuback_p;

f35 = z - zback_p;

%Auxiliary variables for computing moments

f36 = -omegatild + Lambda*omega;

f37 = uctild - (c - gamma*cback - chi*l^(1+varphi)/(1+varphi) )^(-rho);

f38 = -gi + inv/invback;

%output growth

f39 = -gy + output/outputback;

%% Z and z

f40 = -Z + c - gamma*cback - chi*l^(1+varphi)/(1+varphi);

f41 = -z + Z/Zback;

f42 = -z2 + z*zback;

%policy

f43 = -phic + phi/(1-psig);

f44 = -psig + psigbar + nug*( (rk_p - r) - (rkbar - 1/beta) );

%mue, mus

f45 = -mue + Lambda_p*omega_p*(r-re_p);

f46 = -mus + Lambda_p*omega_p*( (1+tau_s)*rk_p-r);

%new stuff

f47 = -LambdaRbar  + (  rback + phiback * ((rk-rback) + xeqback*(rback-re))  )*Lambda;

f48 = -phiback_p + phi;

f49 = -Omega_lev + omega; 

f50 = psi_control - psi;

% shock equations

f51 = psi_p - rhopsi*psi;

f52 = psi_d_p - rhopsi_d*psi_d;



%Create function f
f = [f1;f2;f3;f4;f5;f6;f7;f8;f9;f10;f11;f12;f13;f14;f15;f16;f17;f18;f19;f20;f21;f22;f23;f24;f25;f26;f27;f28;f29;f30;f31;...
    f32;f33;f34;f35;f36;f37;f38;f39;f40;f41;f42;f43;f44;f45;f46;f47;f48;f49;f50;f51;f52];

% Define the vector of controls, y, and states, x

x = [kback Zback zback cback invback nback xeqback Qback qback rback ucback outputback psigback nuback phiback psi psi_d];
xp = [k Zback_p zback_p cback_p invback_p nback_p xeqback_p Qback_p qback_p rback_p ucback_p outputback_p psigback_p nuback_p phiback_p psi_p psi_d_p];

y = [Welf Ut mue mus z z2 Z psig gy output c inv r xeq Q q uc Lambda phi phic theta nu omega mu rk re l spread n omegatild uctild gi LambdaRbar Omega_lev psi_control];
yp =[Welf_p Ut_p mue_p mus_p z_p z2_p Z_p  psig_p gy_p output_p c_p inv_p r_p xeq_p Q_p q_p uc_p Lambda_p phi_p phic_p theta_p nu_p omega_p mu_p rk_p re_p l_p spread_p n_p omegatild_p uctild_p gi_p LambdaRbar_p Omega_lev_p psi_control_p];
  


%%%Make f a function of the logarithm of the state and control vector - take
%%% care of repeated elements in xp and y
vars = [k output mus c Z z z2 Q inv n r q Lambda phi phic theta nu omega mu rk re l uc gy omegatild uctild gi]; %ignore x since we don't want log(x) (x is 0 in ss)
varslead = [output_p mus_p Z_p z_p z2_p c_p Q_p inv_p n_p r_p q_p Lambda_p phi_p phic_p theta_p nu_p omega_p mu_p rk_p re_p l_p uc_p omegatild_p uctild_p gi_p];
varslag = [kback Zback zback cback Qback invback nback rback qback ucback outputback nuback phiback];
varslaglead = [cback_p Zback_p zback_p Qback_p invback_p nback_p rback_p qback_p ucback_p outputback_p nuback_p phiback_p];

%f = subs(f, [x,y,xp,yp], exp([x,y,xp,yp]));
f = subs(f,[vars,varslead,varslag,varslaglead],exp( [vars,varslead,varslag,varslaglead] ));

%Compute analytical derivatives of f
[fx,fxp,fy,fyp,fypyp,fypy,fypxp,fypx,fyyp,fyy,fyxp,fyx,fxpyp,fxpy,fxpxp,fxpx,fxyp,fxy,fxxp,fxx]=anal_deriv(f,x,y,xp,yp);

clear tau tau_s psigbar rkbar nug rho gamma beta betawelf alpha delta psiparam sigma kappa thetaparam xi chi varphi rhopsi sigmapsi rhopsi_d sigmapsi_d epsilon 
clear omegatild_p uctild_p gi_p omegatild uctild gi
clear psig phic psig_p phic_p gy gy_p Welf Welf_p Ut Ut_p c_l c c_p psi psi_l psi_d psi_d_l k_l k inv_l inv inv_p n_l n n_p uc_l uc uc_p l l_p xeq_l xeq xeq_p Q_l Q Q_p q_l q q_p  Lambda Lambda_p r_l r r_p re re_p rk rk_p phi phi_p theta theta_p nu nu_p mu mu_p omega omega_p spread spread_p
clear x xp y yp vars varslead varslag varslaglead output output_p 
clear f1 f2 f3 f4 f5 f6 f7 f8 f9 f10 f11 f12 f13 f14 f15 f16 f17 f18 f19 f20 f21 f22 f23 f24 f25 f26 f27 f28 f29 f30 f31 f32 f33 f34 f35 f36 f37 f38 f39 f40 f41 f42 f43 f44 f45 f46 f47 f48 f49
clear kback cback invback nback xeqback Qback qback rback ucback outputback psigback psi psi_d
clear k cback_p invback_p nback_p xeqback_p Qback_p qback_p rback_p ucback_p outputback_p psigback_p psi_p psi_d_p
clear Z Z_p Zback Zback_p z z_p mue mue_p mus mus_p nuback nuback_p tau_cost
clear phiback phiback_p LambdaRbar Omega_lev LambdaRbar_p Omega_lev_p
clear z2 z2_p zback zback_p
clear f50 f51 tau_cost tau_cost2
clear psi_control psi_control_p f52