%%find deterministic steady state when tau = 0
function X_Steady = fsteady2_det_notau

global beta alpha rho delta chi varphi psiparam gamma psigbar eta sig epsilon kappa tau tau_s sigma xi thetaparam...
      betawelf rhopsi rhopsi_d p D sigma_psi sigma_psi sigma_psid tau_cost nug psigbar Madd


LAMBDA = beta;
R = 1/LAMBDA;
Re = R;
xeq = -epsilon/kappa;
Theta = thetaparam*(1 + epsilon*xeq + .5*kappa*xeq^2);


%set up system of 3 eqs in x,rk,omega
rkdet = 0.01189041248037;
omegadet =  0.46268303712573;

xx0(1,1) = rkdet;
xx0(2,1) = omegadet;



[xxsol,rc]=csolve(@find_det_SIMPLE,xx0,[],1e-09,800);rc
    function f=find_det_SIMPLE(xx);
        [rows,cols]=size(xx);
        for i=1:cols
 
        Rk = exp( xx(1,i) );
        Omega = exp( xx(2,i) );
        
        Mus = ( (1+tau_s)*Rk - R)*Omega*LAMBDA;
        Phi = Omega/(Theta-Mus);
        
        f(1,i) = -Omega + (1-sigma) + sigma*Theta*Phi;
        f(2,i) = -(1-sigma*R) + Phi * ( sigma *( (1+tau_s)*Rk-R) + (1-sigma)*xi );
     
        end
    end


   
Rk = exp(xxsol(1));
Omega = exp(xxsol(2));

Mus = ( (1+tau_s)*Rk - R)*Omega*LAMBDA;
Mue = 0;
Mu = Mus;
Nu = Omega;
Phi = Nu/(Theta-Mu);

Qexp = 1;
MPK = Qexp*( Rk - (1-delta) );
qexp = MPK / (Re - (1-delta) );
KL = ( MPK/alpha )^(1/(alpha-1));
YL = KL^alpha;


L = ( (1-alpha)*YL*( 1 - beta*gamma)/chi )^(1/varphi);

K = KL*L;
Output = YL*L;
CL = YL - delta*KL;
C = CL*L;
I = delta*K;
Zexp = C - gamma*C - chi*L^(1+varphi)/(1+varphi);
Uc = (1-beta*gamma)*Zexp^(-rho);
zexp = 1;



rkbar = Rk;
psig = psigbar;
N = Qexp*K*(1-psig)/Phi;
Spread = Rk - R;
Phic = Phi/(1-psig);
%%------------------------------
K_totaleq = K/(N+xeq*K);
outeq_totaleq = xeq*K/(N+xeq*K);
annual_spread = ( beta*(Rk-R)+1 )^4 - 1;
%%------------------------------

X_Steady( 1,1) = xeq;
X_Steady( 2,1) = K;
X_Steady( 3,1) = C;
X_Steady( 4,1) = I;
X_Steady( 5,1) = N;
X_Steady( 6,1) = Qexp;
X_Steady( 7,1) = qexp;
X_Steady( 8,1) = R;
X_Steady( 9,1) = Rk;
X_Steady(10,1) = Re;
X_Steady(11,1) = Uc;
X_Steady(12,1) = Output;
X_Steady(13,1) = psig;
X_Steady(14,1) = LAMBDA;
X_Steady(15,1) = Phi;
X_Steady(16,1) = Phic;
X_Steady(17,1) = Theta;
X_Steady(18,1) = Nu;
X_Steady(19,1) = Omega;
X_Steady(20,1) = Mu;
X_Steady(21,1) = Mus;
X_Steady(22,1) = Mue;
X_Steady(23,1) = L;


end