function  g_output = g(M);

[rows,cols]=size(M);
       
for i=1:cols
    
g_output(:,i) = M - fmom2( fsteady2(M) );

end