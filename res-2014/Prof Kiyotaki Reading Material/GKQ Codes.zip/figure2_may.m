%%%Build ENTIRE Figure2 (new version - may)

%%%FOR FIGURE 3, RUN THIS SAME FILE WITH HIGH RISK (that is, setting the
%%%first argument of f_risk_adj to 1, at both 7 and 11);

clc;clear all;close all;
X_credit = f_risk_adj(1,100,0);
[IRF_credit,Names]=ffigure2may(X_credit);

clear global 
X_nocredit = f_risk_adj(1,0,0);
[IRF_nocredit,Names]=ffigure2may(X_nocredit);
load RBC_IRFs.mat;
close all;
%%%IRF = [IRFr IRFspread IRFoutput IRFc IRFinv IRFl IRFQ IRFn IRFx];
%%%IRFrbc = [IRFrbc_r NaN(sss) IRFrbc_output IRFrbc_c IRFrbc_inv IRFrbc_l
%%%          IRFrbc_Q NaN(sss) NaN(sss)];

figure
subplot(4,3,1);plot1=plot(1:40,IRF_credit(:,1),1:40,IRF_nocredit(:,1),1:40,IRFrbc_r,'linewidth',1.5);
set(plot1(3),'linestyle',':','color',[.5 .5 .5]);
set(plot1(2),'linestyle','--');
title('R');

subplot(4,3,2);plot2=plot(1:40,IRF_credit(:,2),1:40,IRF_nocredit(:,2),'linewidth',1.5);
set(plot2(2),'linestyle','--');
title('Spread (annual)');

subplot(4,3,3);plot3=plot(1:40,IRF_credit(:,3),1:40,IRF_nocredit(:,3),1:40,IRFrbc_output,'linewidth',1.5);
set(plot3(3),'linestyle',':','color',[.5 .5 .5]);
set(plot3(2),'linestyle','--');
title('Output');

subplot(4,3,4);plot4=plot(1:40,IRF_credit(:,4),1:40,IRF_nocredit(:,4),1:40,IRFrbc_c,'linewidth',1.5);
set(plot4(3),'linestyle',':','color',[.5 .5 .5]);
set(plot4(2),'linestyle','--');
title('C');


subplot(4,3,5);plot5=plot(1:40,IRF_credit(:,5),1:40,IRF_nocredit(:,5),1:40,IRFrbc_inv,'linewidth',1.5);
set(plot5(3),'linestyle',':','color',[.5 .5 .5]);
set(plot5(2),'linestyle','--');
title('Investment');
legend('Credit Policy (\nu_g = 100)','No Credit Policy','RBC');

subplot(4,3,6);plot6=plot(1:40,IRF_credit(:,6),1:40,IRF_nocredit(:,6),1:40,IRFrbc_l,'linewidth',1.5);
set(plot6(3),'linestyle',':','color',[.5 .5 .5]);
set(plot6(2),'linestyle','--');
title('Labor');

subplot(4,3,7);plot7=plot(1:40,IRF_credit(:,7),1:40,IRF_nocredit(:,7),1:40,IRFrbc_Q,'linewidth',1.5);
set(plot7(3),'linestyle',':','color',[.5 .5 .5]);
set(plot7(2),'linestyle','--');
title('Q');

subplot(4,3,8);plot8=plot(1:40,IRF_credit(:,8),1:40,IRF_nocredit(:,8),'linewidth',1.5);
set(plot8(2),'linestyle','--');
title('Net Worth');

subplot(4,3,9);plot9=plot(1:40,IRF_credit(:,9),1:40,IRF_nocredit(:,9),'linewidth',1.5);
set(plot9(2),'linestyle','--');
title('x');

subplot(4,3,10);plot10=plot(1:40,IRF_credit(:,10),1:40,IRF_nocredit(:,10),'linewidth',1.5);
set(plot10(2),'linestyle','--');
title('\zeta');


