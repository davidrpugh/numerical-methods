%%function to calibrate tau_cost, tau_cost2 (efficiency costs of credit
%%policy)
function tau = tau_calib(target); %%target:(50,100,200) bps per unit intermediated in the first 2 years of a bust

%calibrate to hit 2 targets: 1. zero costs in boom; 2. costs in busts
%indicated in argument -- in the first 2 years of crisis

psig_avg = 0.1013; %mean intervention over the first 2 years of a crisis (policy here is written as a quadratic in the FRACTION psig)


xx0 = [0;0];

[xxsol,rc]=csolve(@find_tau,xx0,[],1e-09,800);rc
    function f=find_tau(xx);
        [rows,cols]=size(xx);
        for i=1:cols

        tau1 = xx(1,i);
        tau2 = xx(2,i);

        
        f(1,i) = -tau1 + tau2 * psig_avg;
        
        f(2,i) = -target + 4*(tau1 + tau2*psig_avg)*10000;
        
        
        end
    end

tau(1,1) = xxsol(1);
tau(2,1) = xxsol(2);

end